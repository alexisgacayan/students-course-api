# Campus Connect — Integrated Student Enrollment and Information System

A complete university system that combines **Laboratory 3** (Student Course Management
API) and **Laboratory 4** (Student Information Portal) into **one** project.

- **Frontend:** the Campus Connect portal (HTML/CSS/JavaScript, responsive)
- **Backend:** Python + Flask, exposing a REST API that speaks JSON
- **Database:** SQLite (`database.db`), created automatically on first run

```
Browser (portal)  --HTTP/JSON-->  Flask routes in app.py  -->  SQLite (database.db)
```

---

## 1. Project structure

```
Campus-Connect/
├── app.py                        All Flask routes, the REST API and the SQLite schema
├── database.db                   Created automatically the first time you run the app
├── requirements.txt              Python packages needed (Flask, Flask-Cors, gunicorn)
├── README.md                     This file
├── run.bat                       Windows: first-time setup + run
├── start.bat                     Windows: run again later
├── .gitignore                    Keeps venv/, __pycache__/ and database.db out of Git
├── templates/
│   ├── index.html                Dashboard page
│   ├── students.html             Student list + add form
│   ├── courses.html              Course list + add form (Laboratory 3)
│   ├── enrollment.html           Enrollment form + records
│   └── announcements.html        Announcements page (Laboratory 4)
├── static/
│   ├── css/style.css             Navy and white styling for the Flask pages
│   ├── javascript/script.js      fetch() calls to the REST API
│   └── images/                   Put screenshots or the university logo here
└── screenshots/                  Put your presentation screenshots here
```

### Why each important file exists

| File | Purpose |
| --- | --- |
| `app.py` | Defines the SQLite schema, creates and seeds the database, and exposes every REST endpoint. |
| `database.db` | The actual database file. Students, courses, enrollments and announcements live here. |
| `requirements.txt` | Lets anyone (or Render) install the exact packages with one command. |
| `run.bat` | Creates the virtual environment, installs packages, starts the server. |
| `start.bat` | Starts the server again after the first setup. |
| `templates/*.html` | Plain Flask pages, useful for demonstrating the API without the portal. |
| `static/javascript/script.js` | Shows how the browser talks to the API with `fetch()`. |

---

## 2. Run it on Windows

1. Install Python 3.10 or newer from <https://www.python.org/downloads/>
   (tick **Add Python to PATH** during installation).
2. Double-click **`run.bat`**. The first run creates a virtual environment,
   installs Flask, creates `database.db`, and adds sample records.
3. Open <http://127.0.0.1:5000>.
4. Next time, double-click **`start.bat`**.

### Run it on macOS / Linux

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python app.py
```

---

## 3. REST API reference

Base URL: `http://127.0.0.1:5000/api`

| Method | Endpoint | What it does |
| --- | --- | --- |
| GET | `/health` | Connection check + row counts |
| GET | `/stats` | Dashboard totals and recent activity |
| GET | `/students` | List students (`?q=` to search) |
| GET | `/students/{id}` | One student + their enrollment history |
| POST | `/students` | Create a student |
| PUT | `/students/{id}` | Update a student |
| DELETE | `/students/{id}` | Delete a student (and their enrollments) |
| GET | `/courses` | List courses (`?q=` to search) |
| GET | `/courses/{id}` | One course |
| POST | `/courses` | Create a course |
| PUT | `/courses/{id}` | Update a course |
| DELETE | `/courses/{id}` | Delete a course (and its enrollments) |
| GET | `/enrollments` | List enrollments with student and course names (`?q=`, `?student_id=`) |
| POST | `/enrollments` | Enroll a student — returns **409** for a duplicate or a full course |
| PUT | `/enrollments/{id}` | Change the status (`Pending`, `Approved`, `Rejected`, `Cancelled`) |
| DELETE | `/enrollments/{id}` | Delete an enrollment |
| GET | `/announcements` | List announcements |
| POST | `/announcements` | Create an announcement |
| PUT | `/announcements/{id}` | Update an announcement |
| DELETE | `/announcements/{id}` | Delete an announcement |

Every response is JSON. Errors look like `{"error": "message"}` with a 400, 404 or 409 status.

Example:

```bash
curl http://127.0.0.1:5000/api/students
curl -X POST http://127.0.0.1:5000/api/courses \
     -H "Content-Type: application/json" \
     -d "{\"course_code\":\"CS 330\",\"course_name\":\"Machine Learning\",\"department\":\"College of Computing\"}"
```

---

## 4. Connecting the Campus Connect portal

1. Open the portal and go to **API Connection**.
2. Choose **My Flask REST API**.
3. Enter the base URL — locally `http://127.0.0.1:5000/api`.
4. Click **Test connection**, then **Save connection**.

> Browsers block `http://` requests from an `https://` page. While testing on your
> laptop, use the Flask pages at <http://127.0.0.1:5000>, or deploy the backend to
> Render and paste its `https://…/api` address in the portal.

---

## 5. Upload to GitHub

```bash
git init
git add .
git commit -m "Campus Connect: Flask + SQLite student enrollment system"
git branch -M main
git remote add origin https://github.com/<your-username>/campus-connect.git
git push -u origin main
```

Updating later:

```bash
git add .
git commit -m "Describe what you changed"
git push
```

Never commit `.env`, passwords, or `database.db` — `.gitignore` already excludes them.

---

## 6. Deploy to Render

1. Push the project to GitHub (step 5).
2. In Render: **New → Web Service**, connect the repository.
3. Settings:
   - **Environment:** Python 3
   - **Build command:** `pip install -r requirements.txt`
   - **Start command:** `gunicorn app:app`
4. Environment variables:
   - `CAMPUS_CONNECT_DB` = `/var/data/campus.db`
   - `PYTHON_VERSION` = `3.11.9` (optional)
5. **Persistent storage:** add a Disk mounted at `/var/data` (1 GB is plenty).
   Without a disk, SQLite data is lost every time Render restarts the service.
6. Deploy, then open `https://<your-service>.onrender.com/api/health`.
7. Put `https://<your-service>.onrender.com/api` into the portal's **API Connection** page.

---

## 7. Sample data included

8 students, 8 courses, 8 enrollments and 3 announcements are inserted the first
time the database is created. Delete `database.db` and restart the app to reset it.

All names, emails and numbers are fictional and exist only for classroom testing.
