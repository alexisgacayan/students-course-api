@echo off
REM ==========================================================
REM  Campus Connect - first time setup and run (Windows)
REM  Creates a virtual environment, installs the packages,
REM  then starts the Flask API on http://127.0.0.1:5000
REM ==========================================================
cd /d "%~dp0"

echo [1/3] Creating the virtual environment (only the first time)...
if not exist venv (
    python -m venv venv
)

echo [2/3] Activating the environment and installing requirements...
call venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt

echo [3/3] Starting Campus Connect...
echo Open http://127.0.0.1:5000 in your browser. Press CTRL+C to stop.
python app.py

pause