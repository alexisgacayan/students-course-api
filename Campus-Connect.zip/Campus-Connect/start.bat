@echo off
REM ==========================================================
REM  Campus Connect - quick start (Windows)
REM  Use this after run.bat has been executed once.
REM ==========================================================
cd /d "%~dp0"

if exist venv (
    call venv\Scripts\activate.bat
) else (
    echo The virtual environment is missing. Run run.bat first.
    pause
    exit /b 1
)

echo Starting Campus Connect on http://127.0.0.1:5000
python app.py

pause