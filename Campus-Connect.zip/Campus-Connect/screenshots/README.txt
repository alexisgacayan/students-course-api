Save your laboratory screenshots here before uploading the project to GitHub.
