"""
Campus Connect — Integrated Student Enrollment and Information System
=====================================================================
Laboratory 3 (Student Course Management API) and Laboratory 4 (Student
Information Portal) combined into ONE Flask + SQLite REST API.

How the pieces talk to each other
---------------------------------
Browser (Base44 portal OR the pages in /templates)
        |  HTTP + JSON
        v
Flask routes in this file  ->  sqlite3  ->  database.db
        ^
        |  JSON responses
        +-- every route returns JSON so the portal can render it

Run locally (Windows):  double-click run.bat   (first time)
                        double-click start.bat (afterwards)
Run locally (any OS):   python app.py
Open:                   http://127.0.0.1:5000
"""

import os
import sqlite3
from datetime import date, datetime

from flask import Flask, g, jsonify, render_template, request
from flask_cors import CORS

# ---------------------------------------------------------------------------
# 1. Configuration
# ---------------------------------------------------------------------------
BASE_DIR = os.path.abspath(os.path.dirname(__file__))

# The SQLite file. On Render you point this at a persistent disk, e.g.
# CAMPUS_CONNECT_DB=/var/data/campus.db
DATABASE = os.environ.get("CAMPUS_CONNECT_DB", os.path.join(BASE_DIR, "database.db"))

CAPACITY = 30  # maximum active enrollments per course
STATUSES = ("Pending", "Approved", "Rejected", "Cancelled")

app = Flask(__name__)
CORS(app)  # lets the Base44 portal call this API from another origin
app.config["JSON_SORT_KEYS"] = False


# ---------------------------------------------------------------------------
# 2. Database helpers
# ---------------------------------------------------------------------------
SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role          TEXT NOT NULL DEFAULT 'registrar',
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS students (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id     TEXT UNIQUE NOT NULL,
    first_name     TEXT NOT NULL,
    last_name      TEXT NOT NULL,
    email          TEXT UNIQUE NOT NULL,
    program        TEXT,
    year_level     TEXT,
    contact_number TEXT,
    created_at     TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS courses (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    course_code TEXT UNIQUE NOT NULL,
    course_name TEXT NOT NULL,
    department  TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS enrollments (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id      INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    course_id       INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
    enrollment_date TEXT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'Pending'
                    CHECK (status IN ('Pending', 'Approved', 'Rejected', 'Cancelled')),
    created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS announcements (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    title       TEXT NOT NULL,
    content     TEXT NOT NULL,
    author      TEXT,
    date_posted TEXT NOT NULL
);
"""

SAMPLE_STUDENTS = [
    ("2022-00315", "Kenji", "Villanueva", "kenji.villanueva@northfield.edu", "BS Computer Science", "4th Year", "0917 555 0315"),
    ("2023-00451", "Paolo", "Reyes", "paolo.reyes@northfield.edu", "BS Information Technology", "3rd Year", "0917 555 0451"),
    ("2023-00462", "Bianca", "Lim", "bianca.lim@northfield.edu", "BS Accountancy", "3rd Year", "0917 555 0462"),
    ("2024-00128", "Mariel", "Santos", "mariel.santos@northfield.edu", "BS Computer Science", "2nd Year", "0917 555 0128"),
    ("2024-00137", "Gabriel", "Domingo", "gabriel.domingo@northfield.edu", "BS Civil Engineering", "2nd Year", "0917 555 0137"),
    ("2025-00072", "Angela", "Cruz", "angela.cruz@northfield.edu", "BS Business Administration", "1st Year", "0917 555 0072"),
    ("2025-00084", "Rafael", "Mendoza", "rafael.mendoza@northfield.edu", "BS Nursing", "1st Year", "0917 555 0084"),
    ("2025-00095", "Sofia", "Bautista", "sofia.bautista@northfield.edu", "BS Psychology", "1st Year", "0917 555 0095"),
]

SAMPLE_COURSES = [
    ("CS 311", "Software Engineering Laboratory", "College of Computing"),
    ("CS 322", "Database Systems Laboratory", "College of Computing"),
    ("IT 204", "Web Systems and Technologies", "College of Computing"),
    ("IT 210", "Systems Integration and Architecture", "College of Computing"),
    ("BA 101", "Principles of Management", "College of Business"),
    ("AC 205", "Financial Accounting", "College of Business"),
    ("CE 120", "Statics of Rigid Bodies", "College of Engineering"),
    ("PS 110", "General Psychology", "College of Arts and Sciences"),
]

SAMPLE_ENROLLMENTS = [
    (1, 1, "2026-08-14", "Approved"),
    (2, 3, "2026-08-13", "Pending"),
    (3, 5, "2026-08-13", "Approved"),
    (4, 2, "2026-08-12", "Approved"),
    (5, 7, "2026-08-12", "Pending"),
    (6, 5, "2026-08-11", "Approved"),
    (7, 8, "2026-08-10", "Pending"),
    (8, 4, "2026-08-09", "Cancelled"),
]

SAMPLE_ANNOUNCEMENTS = [
    (
        "Enrollment for the First Semester closes on August 30",
        "All students must complete their course enrollment through Campus Connect before 5:00 PM on "
        "August 30. Late enrollments require the approval of the college secretary.",
        "Registrar's Office",
        "2026-08-12",
    ),
    (
        "Scholarship applications now open",
        "The Northfield University Scholarship Program is accepting applications from second to fourth "
        "year students with a general weighted average of 1.75 or better.",
        "Office of Student Affairs",
        "2026-08-08",
    ),
    (
        "New laboratory courses added to the Computer Science program",
        "CS 311 Software Engineering Laboratory and CS 322 Database Systems Laboratory are now "
        "available for enrollment this semester.",
        "College of Computing",
        "2026-08-05",
    ),
]


def get_db():
    """One SQLite connection per request."""
    if "db" not in g:
        g.db = sqlite3.connect(DATABASE)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(_exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    """Create the tables and add sample rows the first time the app runs."""
    first_time = not os.path.exists(DATABASE)
    connection = sqlite3.connect(DATABASE)
    connection.executescript(SCHEMA)
    connection.execute("PRAGMA foreign_keys = ON")

    if connection.execute("SELECT COUNT(*) FROM students").fetchone()[0] == 0:
        connection.executemany(
            "INSERT INTO students (student_id, first_name, last_name, email, program, year_level, contact_number) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            SAMPLE_STUDENTS,
        )
    if connection.execute("SELECT COUNT(*) FROM courses").fetchone()[0] == 0:
        connection.executemany(
            "INSERT INTO courses (course_code, course_name, department) VALUES (?, ?, ?)",
            SAMPLE_COURSES,
        )
    if connection.execute("SELECT COUNT(*) FROM enrollments").fetchone()[0] == 0:
        connection.executemany(
            "INSERT INTO enrollments (student_id, course_id, enrollment_date, status) VALUES (?, ?, ?, ?)",
            SAMPLE_ENROLLMENTS,
        )
    if connection.execute("SELECT COUNT(*) FROM announcements").fetchone()[0] == 0:
        connection.executemany(
            "INSERT INTO announcements (title, content, author, date_posted) VALUES (?, ?, ?, ?)",
            SAMPLE_ANNOUNCEMENTS,
        )

    connection.commit()
    connection.close()
    print(("[created] " if first_time else "[ready]   ") + DATABASE)


# ---------------------------------------------------------------------------
# 3. Small helpers
# ---------------------------------------------------------------------------
def body():
    return request.get_json(silent=True) or {}


def missing_fields(data, fields):
    return [field for field in fields if not str(data.get(field, "")).strip()]


def student_json(row):
    return {
        "id": row["id"],
        "student_id": row["student_id"],
        "first_name": row["first_name"],
        "last_name": row["last_name"],
        "email": row["email"],
        "program": row["program"],
        "year_level": row["year_level"],
        "contact_number": row["contact_number"],
    }


ENROLLMENT_SELECT = """
SELECT e.id, e.student_id, e.course_id, e.enrollment_date, e.status,
       s.student_id AS student_code,
       s.first_name || ' ' || s.last_name AS student_name,
       c.course_code, c.course_name
FROM enrollments e
JOIN students s ON s.id = e.student_id
JOIN courses c ON c.id = e.course_id
"""


def enrollment_json(row):
    return {
        "id": row["id"],
        "student_id": row["student_id"],
        "course_id": row["course_id"],
        "enrollment_date": row["enrollment_date"],
        "status": row["status"],
        "student_code": row["student_code"],
        "student_name": row["student_name"],
        "course_code": row["course_code"],
        "course_name": row["course_name"],
    }


# ---------------------------------------------------------------------------
# 4. Health + dashboard statistics
# ---------------------------------------------------------------------------
@app.get("/api/health")
def health():
    db = get_db()
    return jsonify(
        {
            "status": "ok",
            "backend": "Campus Connect Flask API",
            "database": os.path.basename(DATABASE),
            "time": datetime.now().isoformat(timespec="seconds"),
            "counts": {
                "students": db.execute("SELECT COUNT(*) FROM students").fetchone()[0],
                "courses": db.execute("SELECT COUNT(*) FROM courses").fetchone()[0],
                "enrollments": db.execute("SELECT COUNT(*) FROM enrollments").fetchone()[0],
                "announcements": db.execute("SELECT COUNT(*) FROM announcements").fetchone()[0],
            },
        }
    )


@app.get("/api/stats")
def stats():
    db = get_db()

    def count(sql, args=()):
        return db.execute(sql, args).fetchone()[0]

    active_per_course = {
        row["course_id"]: row["total"]
        for row in db.execute(
            "SELECT course_id, COUNT(*) AS total FROM enrollments "
            "WHERE status IN ('Pending', 'Approved') GROUP BY course_id"
        )
    }
    total_courses = count("SELECT COUNT(*) FROM courses")
    open_slots = 0
    available = 0
    full = 0
    for course in db.execute("SELECT id FROM courses"):
        taken = active_per_course.get(course["id"], 0)
        remaining = max(0, CAPACITY - taken)
        open_slots += remaining
        if remaining > 0:
            available += 1
        else:
            full += 1

    recent_announcements = [
        dict(row)
        for row in db.execute("SELECT * FROM announcements ORDER BY date_posted DESC, id DESC LIMIT 3")
    ]
    recent_enrollments = [
        enrollment_json(row)
        for row in db.execute(ENROLLMENT_SELECT + " ORDER BY e.enrollment_date DESC, e.id DESC LIMIT 5")
    ]

    return jsonify(
        {
            "total_students": count("SELECT COUNT(*) FROM students"),
            "total_courses": total_courses,
            "total_enrollments": count("SELECT COUNT(*) FROM enrollments"),
            "available_courses": available,
            "programs": count("SELECT COUNT(DISTINCT program) FROM students"),
            "departments": count("SELECT COUNT(DISTINCT department) FROM courses"),
            "year_levels": count("SELECT COUNT(DISTINCT year_level) FROM students"),
            "pending_enrollments": count("SELECT COUNT(*) FROM enrollments WHERE status = 'Pending'"),
            "approved_enrollments": count("SELECT COUNT(*) FROM enrollments WHERE status = 'Approved'"),
            "rejected_enrollments": count("SELECT COUNT(*) FROM enrollments WHERE status = 'Rejected'"),
            "cancelled_enrollments": count("SELECT COUNT(*) FROM enrollments WHERE status = 'Cancelled'"),
            "capacity": total_courses * CAPACITY,
            "open_slots": open_slots,
            "full_courses": full,
            "recent_announcements": recent_announcements,
            "recent_enrollments": recent_enrollments,
        }
    )


# ---------------------------------------------------------------------------
# 5. Students  (GET / POST / PUT / DELETE)
# ---------------------------------------------------------------------------
STUDENT_FIELDS = ("student_id", "first_name", "last_name", "email", "program", "year_level", "contact_number")


@app.get("/api/students")
def list_students():
    db = get_db()
    search = request.args.get("q", "").strip()
    if search:
        like = "%" + search + "%"
        rows = db.execute(
            "SELECT * FROM students WHERE student_id LIKE ? OR first_name LIKE ? OR last_name LIKE ? "
            "OR email LIKE ? OR program LIKE ? OR year_level LIKE ? OR contact_number LIKE ? "
            "ORDER BY student_id",
            (like, like, like, like, like, like, like),
        ).fetchall()
    else:
        rows = db.execute("SELECT * FROM students ORDER BY student_id").fetchall()
    return jsonify([student_json(row) for row in rows])


@app.get("/api/students/<int:student_pk>")
def get_student(student_pk):
    db = get_db()
    row = db.execute("SELECT * FROM students WHERE id = ?", (student_pk,)).fetchone()
    if row is None:
        return jsonify({"error": "Student not found."}), 404
    payload = student_json(row)
    payload["enrollments"] = [
        enrollment_json(item)
        for item in db.execute(ENROLLMENT_SELECT + " WHERE e.student_id = ? ORDER BY e.enrollment_date DESC", (student_pk,))
    ]
    return jsonify(payload)


@app.post("/api/students")
def create_student():
    data = body()
    missing = missing_fields(data, ("student_id", "first_name", "last_name", "email"))
    if missing:
        return jsonify({"error": "Missing required fields: " + ", ".join(missing)}), 400

    db = get_db()
    clash = db.execute(
        "SELECT first_name, last_name FROM students WHERE student_id = ? OR LOWER(email) = LOWER(?)",
        (data["student_id"].strip(), data["email"].strip()),
    ).fetchone()
    if clash:
        return jsonify({"error": "Student ID or email is already used by %s %s." % (clash["first_name"], clash["last_name"])}), 409

    cursor = db.execute(
        "INSERT INTO students (student_id, first_name, last_name, email, program, year_level, contact_number) "
        "VALUES (?, ?, ?, ?, ?, ?, ?)",
        (
            data["student_id"].strip(),
            data["first_name"].strip(),
            data["last_name"].strip(),
            data["email"].strip(),
            str(data.get("program", "")).strip(),
            str(data.get("year_level", "")).strip(),
            str(data.get("contact_number", "")).strip(),
        ),
    )
    db.commit()
    row = db.execute("SELECT * FROM students WHERE id = ?", (cursor.lastrowid,)).fetchone()
    return jsonify(student_json(row)), 201


@app.put("/api/students/<int:student_pk>")
def update_student(student_pk):
    data = body()
    db = get_db()
    existing = db.execute("SELECT * FROM students WHERE id = ?", (student_pk,)).fetchone()
    if existing is None:
        return jsonify({"error": "Student not found."}), 404

    missing = missing_fields(data, ("student_id", "first_name", "last_name", "email"))
    if missing:
        return jsonify({"error": "Missing required fields: " + ", ".join(missing)}), 400

    clash = db.execute(
        "SELECT id FROM students WHERE id != ? AND (student_id = ? OR LOWER(email) = LOWER(?))",
        (student_pk, data["student_id"].strip(), data["email"].strip()),
    ).fetchone()
    if clash:
        return jsonify({"error": "Another student already uses that student ID or email."}), 409

    db.execute(
        "UPDATE students SET student_id = ?, first_name = ?, last_name = ?, email = ?, program = ?, "
        "year_level = ?, contact_number = ? WHERE id = ?",
        (
            data["student_id"].strip(),
            data["first_name"].strip(),
            data["last_name"].strip(),
            data["email"].strip(),
            str(data.get("program", "")).strip(),
            str(data.get("year_level", "")).strip(),
            str(data.get("contact_number", "")).strip(),
            student_pk,
        ),
    )
    db.commit()
    row = db.execute("SELECT * FROM students WHERE id = ?", (student_pk,)).fetchone()
    return jsonify(student_json(row))


@app.delete("/api/students/<int:student_pk>")
def delete_student(student_pk):
    db = get_db()
    existing = db.execute("SELECT id FROM students WHERE id = ?", (student_pk,)).fetchone()
    if existing is None:
        return jsonify({"error": "Student not found."}), 404
    deleted_enrollments = db.execute("SELECT COUNT(*) FROM enrollments WHERE student_id = ?", (student_pk,)).fetchone()[0]
    db.execute("DELETE FROM students WHERE id = ?", (student_pk,))
    db.commit()
    return jsonify({"success": True, "deleted_enrollments": deleted_enrollments})


# ---------------------------------------------------------------------------
# 6. Courses  (Laboratory 3 — Student Course Management API)
# ---------------------------------------------------------------------------
@app.get("/api/courses")
def list_courses():
    db = get_db()
    search = request.args.get("q", "").strip()
    if search:
        like = "%" + search + "%"
        rows = db.execute(
            "SELECT * FROM courses WHERE course_code LIKE ? OR course_name LIKE ? OR department LIKE ? "
            "ORDER BY course_code",
            (like, like, like),
        ).fetchall()
    else:
        rows = db.execute("SELECT * FROM courses ORDER BY course_code").fetchall()
    return jsonify([dict(row) for row in rows])


@app.get("/api/courses/<int:course_pk>")
def get_course(course_pk):
    db = get_db()
    row = db.execute("SELECT * FROM courses WHERE id = ?", (course_pk,)).fetchone()
    if row is None:
        return jsonify({"error": "Course not found."}), 404
    return jsonify(dict(row))


@app.post("/api/courses")
def create_course():
    data = body()
    missing = missing_fields(data, ("course_code", "course_name"))
    if missing:
        return jsonify({"error": "Missing required fields: " + ", ".join(missing)}), 400

    db = get_db()
    code = data["course_code"].strip().upper()
    clash = db.execute("SELECT id FROM courses WHERE course_code = ?", (code,)).fetchone()
    if clash:
        return jsonify({"error": "Course code %s already exists." % code}), 409

    cursor = db.execute(
        "INSERT INTO courses (course_code, course_name, department) VALUES (?, ?, ?)",
        (code, data["course_name"].strip(), str(data.get("department", "")).strip()),
    )
    db.commit()
    row = db.execute("SELECT * FROM courses WHERE id = ?", (cursor.lastrowid,)).fetchone()
    return jsonify(dict(row)), 201


@app.put("/api/courses/<int:course_pk>")
def update_course(course_pk):
    data = body()
    db = get_db()
    existing = db.execute("SELECT id FROM courses WHERE id = ?", (course_pk,)).fetchone()
    if existing is None:
        return jsonify({"error": "Course not found."}), 404

    missing = missing_fields(data, ("course_code", "course_name"))
    if missing:
        return jsonify({"error": "Missing required fields: " + ", ".join(missing)}), 400

    code = data["course_code"].strip().upper()
    clash = db.execute("SELECT id FROM courses WHERE id != ? AND course_code = ?", (course_pk, code)).fetchone()
    if clash:
        return jsonify({"error": "Course code %s already exists." % code}), 409

    db.execute(
        "UPDATE courses SET course_code = ?, course_name = ?, department = ? WHERE id = ?",
        (code, data["course_name"].strip(), str(data.get("department", "")).strip(), course_pk),
    )
    db.commit()
    row = db.execute("SELECT * FROM courses WHERE id = ?", (course_pk,)).fetchone()
    return jsonify(dict(row))


@app.delete("/api/courses/<int:course_pk>")
def delete_course(course_pk):
    db = get_db()
    existing = db.execute("SELECT id FROM courses WHERE id = ?", (course_pk,)).fetchone()
    if existing is None:
        return jsonify({"error": "Course not found."}), 404
    deleted_enrollments = db.execute("SELECT COUNT(*) FROM enrollments WHERE course_id = ?", (course_pk,)).fetchone()[0]
    db.execute("DELETE FROM courses WHERE id = ?", (course_pk,))
    db.commit()
    return jsonify({"success": True, "deleted_enrollments": deleted_enrollments})


# ---------------------------------------------------------------------------
# 7. Enrollments  (the module that joins students and courses)
# ---------------------------------------------------------------------------
@app.get("/api/enrollments")
def list_enrollments():
    db = get_db()
    sql = ENROLLMENT_SELECT + " WHERE 1 = 1"
    args = []

    student_pk = request.args.get("student_id", "").strip()
    if student_pk:
        sql += " AND e.student_id = ?"
        args.append(student_pk)

    search = request.args.get("q", "").strip()
    if search:
        like = "%" + search + "%"
        sql += (
            " AND (s.first_name LIKE ? OR s.last_name LIKE ? OR s.student_id LIKE ? "
            "OR c.course_code LIKE ? OR c.course_name LIKE ? OR e.status LIKE ?)"
        )
        args.extend([like, like, like, like, like, like])

    sql += " ORDER BY e.enrollment_date DESC, e.id DESC"
    return jsonify([enrollment_json(row) for row in db.execute(sql, args)])


@app.post("/api/enrollments")
def create_enrollment():
    data = body()
    student_pk = data.get("student_id")
    course_pk = data.get("course_id")
    if not student_pk or not course_pk:
        return jsonify({"error": "Choose both a student and a course."}), 400

    db = get_db()
    student = db.execute("SELECT * FROM students WHERE id = ?", (student_pk,)).fetchone()
    course = db.execute("SELECT * FROM courses WHERE id = ?", (course_pk,)).fetchone()
    if student is None:
        return jsonify({"error": "That student no longer exists."}), 404
    if course is None:
        return jsonify({"error": "That course no longer exists."}), 404

    duplicate = db.execute(
        "SELECT id FROM enrollments WHERE student_id = ? AND course_id = ? AND status != 'Cancelled'",
        (student_pk, course_pk),
    ).fetchone()
    if duplicate:
        return jsonify(
            {"error": "%s %s is already enrolled in %s." % (student["first_name"], student["last_name"], course["course_code"])}
        ), 409

    taken = db.execute(
        "SELECT COUNT(*) FROM enrollments WHERE course_id = ? AND status IN ('Pending', 'Approved')", (course_pk,)
    ).fetchone()[0]
    if taken >= CAPACITY:
        return jsonify({"error": "%s is already full (%d slots)." % (course["course_code"], CAPACITY)}), 409

    status = data.get("status", "Pending")
    if status not in STATUSES:
        status = "Pending"
    enrollment_date = str(data.get("enrollment_date") or date.today().isoformat())

    cursor = db.execute(
        "INSERT INTO enrollments (student_id, course_id, enrollment_date, status) VALUES (?, ?, ?, ?)",
        (student_pk, course_pk, enrollment_date, status),
    )
    db.commit()
    row = db.execute(ENROLLMENT_SELECT + " WHERE e.id = ?", (cursor.lastrowid,)).fetchone()
    return jsonify(enrollment_json(row)), 201


@app.put("/api/enrollments/<int:enrollment_pk>")
def update_enrollment(enrollment_pk):
    data = body()
    status = data.get("status")
    if status not in STATUSES:
        return jsonify({"error": "Status must be one of: " + ", ".join(STATUSES)}), 400

    db = get_db()
    existing = db.execute("SELECT id FROM enrollments WHERE id = ?", (enrollment_pk,)).fetchone()
    if existing is None:
        return jsonify({"error": "Enrollment not found."}), 404

    db.execute("UPDATE enrollments SET status = ? WHERE id = ?", (status, enrollment_pk))
    db.commit()
    row = db.execute(ENROLLMENT_SELECT + " WHERE e.id = ?", (enrollment_pk,)).fetchone()
    return jsonify(enrollment_json(row))


@app.delete("/api/enrollments/<int:enrollment_pk>")
def delete_enrollment(enrollment_pk):
    db = get_db()
    existing = db.execute("SELECT id FROM enrollments WHERE id = ?", (enrollment_pk,)).fetchone()
    if existing is None:
        return jsonify({"error": "Enrollment not found."}), 404
    db.execute("DELETE FROM enrollments WHERE id = ?", (enrollment_pk,))
    db.commit()
    return jsonify({"success": True})


# ---------------------------------------------------------------------------
# 8. Announcements  (Laboratory 4 — Student Information Portal)
# ---------------------------------------------------------------------------
@app.get("/api/announcements")
def list_announcements():
    db = get_db()
    search = request.args.get("q", "").strip()
    if search:
        like = "%" + search + "%"
        rows = db.execute(
            "SELECT * FROM announcements WHERE title LIKE ? OR content LIKE ? OR author LIKE ? "
            "ORDER BY date_posted DESC, id DESC",
            (like, like, like),
        ).fetchall()
    else:
        rows = db.execute("SELECT * FROM announcements ORDER BY date_posted DESC, id DESC").fetchall()
    return jsonify([dict(row) for row in rows])


@app.get("/api/announcements/<int:announcement_pk>")
def get_announcement(announcement_pk):
    db = get_db()
    row = db.execute("SELECT * FROM announcements WHERE id = ?", (announcement_pk,)).fetchone()
    if row is None:
        return jsonify({"error": "Announcement not found."}), 404
    return jsonify(dict(row))


@app.post("/api/announcements")
def create_announcement():
    data = body()
    missing = missing_fields(data, ("title", "content"))
    if missing:
        return jsonify({"error": "Missing required fields: " + ", ".join(missing)}), 400

    db = get_db()
    cursor = db.execute(
        "INSERT INTO announcements (title, content, author, date_posted) VALUES (?, ?, ?, ?)",
        (
            data["title"].strip(),
            data["content"].strip(),
            str(data.get("author") or "Registrar's Office").strip(),
            str(data.get("date_posted") or date.today().isoformat()),
        ),
    )
    db.commit()
    row = db.execute("SELECT * FROM announcements WHERE id = ?", (cursor.lastrowid,)).fetchone()
    return jsonify(dict(row)), 201


@app.put("/api/announcements/<int:announcement_pk>")
def update_announcement(announcement_pk):
    data = body()
    db = get_db()
    existing = db.execute("SELECT * FROM announcements WHERE id = ?", (announcement_pk,)).fetchone()
    if existing is None:
        return jsonify({"error": "Announcement not found."}), 404

    missing = missing_fields(data, ("title", "content"))
    if missing:
        return jsonify({"error": "Missing required fields: " + ", ".join(missing)}), 400

    db.execute(
        "UPDATE announcements SET title = ?, content = ?, author = ?, date_posted = ? WHERE id = ?",
        (
            data["title"].strip(),
            data["content"].strip(),
            str(data.get("author") or existing["author"]).strip(),
            str(data.get("date_posted") or existing["date_posted"]),
            announcement_pk,
        ),
    )
    db.commit()
    row = db.execute("SELECT * FROM announcements WHERE id = ?", (announcement_pk,)).fetchone()
    return jsonify(dict(row))


@app.delete("/api/announcements/<int:announcement_pk>")
def delete_announcement(announcement_pk):
    db = get_db()
    existing = db.execute("SELECT id FROM announcements WHERE id = ?", (announcement_pk,)).fetchone()
    if existing is None:
        return jsonify({"error": "Announcement not found."}), 404
    db.execute("DELETE FROM announcements WHERE id = ?", (announcement_pk,))
    db.commit()
    return jsonify({"success": True})


# ---------------------------------------------------------------------------
# 9. Plain Flask pages (fallback user interface, served from /templates)
# ---------------------------------------------------------------------------
@app.get("/")
def page_dashboard():
    return render_template("index.html")


@app.get("/students")
def page_students():
    return render_template("students.html")


@app.get("/courses")
def page_courses():
    return render_template("courses.html")


@app.get("/enrollment")
def page_enrollment():
    return render_template("enrollment.html")


@app.get("/announcements")
def page_announcements():
    return render_template("announcements.html")


# ---------------------------------------------------------------------------
# 10. Start
# ---------------------------------------------------------------------------
init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=True)