Put the university logo or exported screenshots for your presentation in this folder.
