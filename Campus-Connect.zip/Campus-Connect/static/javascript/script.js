/* Campus Connect — shared frontend logic for the Flask-rendered pages.
   Every function below talks to the REST API in app.py with fetch(). */

const API = "/api";

async function apiGet(path) {
  const response = await fetch(API + path);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Request failed (" + response.status + ")");
  return data;
}

async function apiSend(path, method, payload) {
  const response = await fetch(API + path, {
    method: method,
    headers: { "Content-Type": "application/json" },
    body: payload ? JSON.stringify(payload) : undefined,
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Request failed (" + response.status + ")");
  return data;
}

function escapeHtml(value) {
  return String(value === null || value === undefined ? "" : value).replace(/[&<>"']/g, function (character) {
    return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[character];
  });
}

function showMessage(id, text, isError) {
  const node = document.getElementById(id);
  if (!node) return;
  node.textContent = text;
  node.className = "message " + (isError ? "error" : "success");
}

function formValues(form) {
  const values = {};
  new FormData(form).forEach(function (value, key) {
    values[key] = value;
  });
  return values;
}

function badge(status) {
  return '<span class="badge ' + escapeHtml(status) + '">' + escapeHtml(status) + "</span>";
}

/* ---------------------------------------------------------------- dashboard */
async function renderDashboard() {
  const stats = await apiGet("/stats");

  document.getElementById("stats").innerHTML = [
    ["Total students", stats.total_students],
    ["Total courses", stats.total_courses],
    ["Total enrollments", stats.total_enrollments],
    ["Available courses", stats.available_courses],
  ]
    .map(function (item) {
      return '<div class="stat"><span>' + item[0] + "</span><strong>" + item[1] + "</strong></div>";
    })
    .join("");

  document.getElementById("announcements").innerHTML =
    stats.recent_announcements
      .map(function (item) {
        return (
          "<li><strong>" +
          escapeHtml(item.title) +
          "</strong><small>" +
          escapeHtml(item.date_posted) +
          " · " +
          escapeHtml(item.author) +
          "</small></li>"
        );
      })
      .join("") || '<li class="muted">No announcements yet.</li>';

  const rows = stats.recent_enrollments
    .map(function (item) {
      return (
        "<tr><td>" +
        escapeHtml(item.student_name) +
        "<br><small class='muted'>" +
        escapeHtml(item.student_code) +
        "</small></td><td>" +
        escapeHtml(item.course_code) +
        "<br><small class='muted'>" +
        escapeHtml(item.course_name) +
        "</small></td><td>" +
        escapeHtml(item.enrollment_date) +
        "</td><td>" +
        badge(item.status) +
        "</td></tr>"
      );
    })
    .join("");

  document.querySelector("#activity tbody").innerHTML =
    rows || '<tr><td colspan="4" class="muted">No enrollment activity yet.</td></tr>';
}

/* ----------------------------------------------------------------- students */
async function loadStudents() {
  const students = await apiGet("/students");
  const body = document.querySelector("#students-table tbody");
  body.innerHTML =
    students
      .map(function (student) {
        return (
          "<tr><td>" +
          escapeHtml(student.student_id) +
          "</td><td>" +
          escapeHtml(student.first_name + " " + student.last_name) +
          "</td><td>" +
          escapeHtml(student.email) +
          "</td><td>" +
          escapeHtml(student.program) +
          "</td><td>" +
          escapeHtml(student.year_level) +
          "</td></tr>"
        );
      })
      .join("") || '<tr><td colspan="5" class="muted">No students yet.</td></tr>';
}

async function renderStudents() {
  await loadStudents();
  document.getElementById("student-form").addEventListener("submit", async function (event) {
    event.preventDefault();
    try {
      await apiSend("/students", "POST", formValues(event.target));
      showMessage("student-message", "Student saved to SQLite.", false);
      event.target.reset();
      await loadStudents();
    } catch (error) {
      showMessage("student-message", error.message, true);
    }
  });
}

/* ------------------------------------------------------------------ courses */
async function loadCourses() {
  const courses = await apiGet("/courses");
  const body = document.querySelector("#courses-table tbody");
  body.innerHTML =
    courses
      .map(function (course) {
        return (
          "<tr><td>" +
          escapeHtml(course.id) +
          "</td><td>" +
          escapeHtml(course.course_code) +
          "</td><td>" +
          escapeHtml(course.course_name) +
          "</td><td>" +
          escapeHtml(course.department) +
          '</td><td><button class="ghost" data-delete-course="' +
          course.id +
          '">Delete</button></td></tr>'
        );
      })
      .join("") || '<tr><td colspan="5" class="muted">No courses yet.</td></tr>';
}

async function renderCourses() {
  await loadCourses();

  document.getElementById("course-form").addEventListener("submit", async function (event) {
    event.preventDefault();
    try {
      await apiSend("/courses", "POST", formValues(event.target));
      showMessage("course-message", "Course saved to SQLite.", false);
      event.target.reset();
      await loadCourses();
    } catch (error) {
      showMessage("course-message", error.message, true);
    }
  });

  document.getElementById("courses-table").addEventListener("click", async function (event) {
    const button = event.target.closest("[data-delete-course]");
    if (!button) return;
    if (!window.confirm("Delete this course and its enrollments?")) return;
    try {
      await apiSend("/courses/" + button.dataset.deleteCourse, "DELETE");
      await loadCourses();
    } catch (error) {
      showMessage("course-message", error.message, true);
    }
  });
}

/* --------------------------------------------------------------- enrollment */
async function loadEnrollments() {
  const enrollments = await apiGet("/enrollments");
  const body = document.querySelector("#enrollments-table tbody");
  body.innerHTML =
    enrollments
      .map(function (row) {
        const options = ["Pending", "Approved", "Rejected", "Cancelled"]
          .map(function (status) {
            return (
              '<option value="' +
              status +
              '"' +
              (row.status === status ? " selected" : "") +
              ">" +
              status +
              "</option>"
            );
          })
          .join("");
        return (
          "<tr><td>" +
          escapeHtml(row.id) +
          "</td><td>" +
          escapeHtml(row.student_name) +
          "<br><small class='muted'>" +
          escapeHtml(row.student_code) +
          "</small></td><td>" +
          escapeHtml(row.course_code) +
          "<br><small class='muted'>" +
          escapeHtml(row.course_name) +
          "</small></td><td>" +
          escapeHtml(row.enrollment_date) +
          '</td><td><select data-enrollment="' +
          row.id +
          '">' +
          options +
          '</select></td><td><button class="ghost" data-delete-enrollment="' +
          row.id +
          '">Delete</button></td></tr>'
        );
      })
      .join("") || '<tr><td colspan="6" class="muted">No enrollments yet.</td></tr>';
}

async function renderEnrollment() {
  const students = await apiGet("/students");
  const courses = await apiGet("/courses");

  document.getElementById("student-select").innerHTML =
    '<option value="">Select a student…</option>' +
    students
      .map(function (student) {
        return (
          '<option value="' +
          student.id +
          '">' +
          escapeHtml(student.student_id + " · " + student.first_name + " " + student.last_name) +
          "</option>"
        );
      })
      .join("");

  document.getElementById("course-select").innerHTML =
    '<option value="">Select a course…</option>' +
    courses
      .map(function (course) {
        return (
          '<option value="' +
          course.id +
          '">' +
          escapeHtml(course.course_code + " · " + course.course_name) +
          "</option>"
        );
      })
      .join("");

  await loadEnrollments();

  document.getElementById("enrollment-form").addEventListener("submit", async function (event) {
    event.preventDefault();
    const values = formValues(event.target);
    values.student_id = Number(values.student_id);
    values.course_id = Number(values.course_id);
    try {
      await apiSend("/enrollments", "POST", values);
      showMessage("enrollment-message", "Enrollment saved to SQLite.", false);
      event.target.reset();
      await loadEnrollments();
    } catch (error) {
      showMessage("enrollment-message", error.message, true);
    }
  });

  const table = document.getElementById("enrollments-table");

  table.addEventListener("change", async function (event) {
    const select = event.target.closest("[data-enrollment]");
    if (!select) return;
    try {
      await apiSend("/enrollments/" + select.dataset.enrollment, "PUT", { status: select.value });
      showMessage("enrollment-message", "Status updated to " + select.value + ".", false);
      await loadEnrollments();
    } catch (error) {
      showMessage("enrollment-message", error.message, true);
    }
  });

  table.addEventListener("click", async function (event) {
    const button = event.target.closest("[data-delete-enrollment]");
    if (!button) return;
    if (!window.confirm("Delete this enrollment record?")) return;
    try {
      await apiSend("/enrollments/" + button.dataset.deleteEnrollment, "DELETE");
      await loadEnrollments();
    } catch (error) {
      showMessage("enrollment-message", error.message, true);
    }
  });
}

/* ------------------------------------------------------------ announcements */
async function loadAnnouncements() {
  const announcements = await apiGet("/announcements");
  const list = document.getElementById("announcements-list");
  list.innerHTML =
    announcements
      .map(function (item) {
        return (
          '<article class="notice"><h3>' +
          escapeHtml(item.title) +
          "</h3><p>" +
          escapeHtml(item.content) +
          "</p><small>" +
          escapeHtml(item.date_posted) +
          " · " +
          escapeHtml(item.author) +
          "</small></article>"
        );
      })
      .join("") || '<p class="muted">No announcements yet.</p>';
}

async function renderAnnouncements() {
  await loadAnnouncements();
  document.getElementById("announcement-form").addEventListener("submit", async function (event) {
    event.preventDefault();
    try {
      await apiSend("/announcements", "POST", formValues(event.target));
      showMessage("announcement-message", "Announcement published.", false);
      event.target.reset();
      await loadAnnouncements();
    } catch (error) {
      showMessage("announcement-message", error.message, true);
    }
  });
}

/* ------------------------------------------------------------------- start */
document.addEventListener("DOMContentLoaded", function () {
  const page = document.body.dataset.page;
  const renderers = {
    dashboard: renderDashboard,
    students: renderStudents,
    courses: renderCourses,
    enrollment: renderEnrollment,
    announcements: renderAnnouncements,
  };
  const render = renderers[page];
  if (render) {
    render().catch(function (error) {
      console.error("Campus Connect:", error.message);
    });
  }
});